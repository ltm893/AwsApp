const path = require('path');
 const express = require('express')
 var cors = require('cors')
const app = express()
const port = 8080

app.use(express.static('public'));

if (process.env.NODE_ENV === 'dev' || process.env.NODE_ENV === 'ami' || ) {
  app.use(express.errorHandler({ dumpExceptions: true, showStack: true }));
}
if (process.env.NODE_ENV === 'prod') {
  app.use(express.errorHandler());
}

var corsOptions = {
  origin: 'http://localhost:3000' 
}


app.get("/", cors(corsOptions), (req, res)  => {
  res.status(200).json({ title: "this is how we move" });
});

app.get("/ec2", cors(corsOptions), (req, res) => {
  console.log(__dirname)
  res.sendFile(path.join(__dirname,'public/ec2details.txt')) ;
}); 
  
app.options('*', (req,res) => {
    res.send(200);
})

app.get('/', (req, res) => {
  console.log("Get Default")
  res.send("Default PAGE NOT FOUND");
});

app.listen(port, () => {
    console.log(`App listening on port ${port}`)
})       
